import React, { useState, useRef } from 'react';
import { splitImageWithBleed } from '../utils/imageProcessing';
import { downloadImage } from '../utils/downloadUtils';
import { ImagePart } from '../types/image';

const ImageSplitter = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [splitImages, setSplitImages] = useState<ImagePart[]>([]);
  const [splitDirection, setSplitDirection] = useState<'horizontal' | 'vertical'>('horizontal');
  const [partsCount, setPartsCount] = useState<number>(3);
  const [bleedPercentage, setBleedPercentage] = useState<number>(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setSelectedImage(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const splitImage = () => {
    if (!selectedImage || !canvasRef.current) return;

    const img = new Image();
    img.src = selectedImage;
    img.onload = () => {
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext('2d')!;
      
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      
      const parts = splitImageWithBleed(canvas, img, partsCount, splitDirection, bleedPercentage);
      setSplitImages(parts);
    };
  };

  const handleDownload = (dataUrl: string, index: number) => {
    downloadImage(dataUrl, `parca_${index + 1}.png`);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="mb-4 block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100"
        />
        
        {selectedImage && (
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="horizontal"
                  checked={splitDirection === 'horizontal'}
                  onChange={(e) => setSplitDirection('horizontal')}
                  className="mr-2"
                />
                Yatay Böl
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="vertical"
                  checked={splitDirection === 'vertical'}
                  onChange={(e) => setSplitDirection('vertical')}
                  className="mr-2"
                />
                Dikey Böl
              </label>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">
                  Parça Sayısı (1-8):
                </label>
                <input
                  type="number"
                  min="1"
                  max="8"
                  value={partsCount}
                  onChange={(e) => setPartsCount(Math.min(8, Math.max(1, parseInt(e.target.value) || 1)))}
                  className="w-20 px-2 py-1 border rounded-md"
                />
              </div>

              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">
                  Taşma Payı (%1-%5):
                </label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  step="0.1"
                  value={bleedPercentage}
                  onChange={(e) => setBleedPercentage(Math.min(5, Math.max(1, parseFloat(e.target.value) || 1)))}
                  className="w-20 px-2 py-1 border rounded-md"
                />
              </div>
            </div>
            
            <button
              onClick={splitImage}
              className="bg-blue-500 text-white px-4 py-2 rounded-md
                hover:bg-blue-600 transition-colors"
            >
              Resmi Böl
            </button>
          </div>
        )}
      </div>

      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {selectedImage && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Orijinal Görsel:</h3>
          <img src={selectedImage} alt="Original" className="max-w-full h-auto" />
        </div>
      )}

      {splitImages.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-2">Bölünmüş Parçalar:</h3>
          <p className="text-sm text-gray-600 mb-4">
            Her parçada %{bleedPercentage} taşma payı ve kırpma işaretleri eklenmiştir.
          </p>
          <div className={`grid gap-4 ${
            splitDirection === 'vertical' 
              ? 'grid-cols-2 md:grid-cols-4' 
              : 'grid-cols-1'
          }`}>
            {splitImages.map((part) => (
              <div key={part.index} className="border rounded-lg p-2">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm text-gray-600">
                    Parça {part.index + 1}
                    {part.hasTopBleed && ' (Üst Taşma)'}
                    {part.hasBottomBleed && ' (Alt Taşma)'}
                    {part.hasLeftBleed && ' (Sol Taşma)'}
                    {part.hasRightBleed && ' (Sağ Taşma)'}
                  </p>
                  <button
                    onClick={() => handleDownload(part.dataUrl, part.index)}
                    className="text-blue-500 hover:text-blue-700 text-sm"
                  >
                    İndir
                  </button>
                </div>
                <img src={part.dataUrl} alt={`Part ${part.index + 1}`} className="max-w-full h-auto" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageSplitter;