export interface ImagePart {
  dataUrl: string;
  index: number;
  hasTopBleed?: boolean;
  hasBottomBleed?: boolean;
  hasLeftBleed?: boolean;
  hasRightBleed?: boolean;
}