export interface BleedConfig {
  percentage: number;
  direction: 'horizontal' | 'vertical';
  showTrimMarks: boolean;
}