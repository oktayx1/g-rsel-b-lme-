export const calculateBleedMargin = (
  dimension: number,
  percentage: number
): number => {
  return Math.round(dimension * (percentage / 100));
};