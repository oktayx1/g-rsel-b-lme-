import { ImagePart } from '../types/image';
import { calculateBleedMargin } from './bleedCalculations';

export const splitImageWithBleed = (
  canvas: HTMLCanvasElement,
  img: HTMLImageElement,
  partsCount: number,
  direction: 'horizontal' | 'vertical',
  bleedPercentage: number
): ImagePart[] => {
  const ctx = canvas.getContext('2d')!;
  const parts: ImagePart[] = [];

  if (direction === 'horizontal') {
    const partHeight = Math.floor(img.height / partsCount);
    const bleedMargin = calculateBleedMargin(partHeight, bleedPercentage);
    
    for (let i = 0; i < partsCount; i++) {
      const partCanvas = document.createElement('canvas');
      const startY = i * partHeight;
      
      partCanvas.width = img.width;
      partCanvas.height = partHeight + (2 * bleedMargin);
      
      const partCtx = partCanvas.getContext('2d')!;
      
      partCtx.drawImage(
        canvas,
        0,
        Math.max(0, startY - bleedMargin),
        img.width,
        partHeight + (2 * bleedMargin),
        0,
        0,
        partCanvas.width,
        partCanvas.height
      );
      
      parts.push({
        dataUrl: partCanvas.toDataURL(),
        index: i,
        hasTopBleed: i > 0,
        hasBottomBleed: i < partsCount - 1
      });
    }
  } else {
    const partWidth = Math.floor(img.width / partsCount);
    const bleedMargin = calculateBleedMargin(partWidth, bleedPercentage);
    
    for (let i = 0; i < partsCount; i++) {
      const partCanvas = document.createElement('canvas');
      const startX = i * partWidth;
      
      partCanvas.width = partWidth + (2 * bleedMargin);
      partCanvas.height = img.height;
      
      const partCtx = partCanvas.getContext('2d')!;
      
      partCtx.drawImage(
        canvas,
        Math.max(0, startX - bleedMargin),
        0,
        partWidth + (2 * bleedMargin),
        img.height,
        0,
        0,
        partCanvas.width,
        partCanvas.height
      );
      
      parts.push({
        dataUrl: partCanvas.toDataURL(),
        index: i,
        hasLeftBleed: i > 0,
        hasRightBleed: i < partsCount - 1
      });
    }
  }

  return parts;
};